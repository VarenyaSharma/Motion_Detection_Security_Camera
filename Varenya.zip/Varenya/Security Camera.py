import cv2
import winsound
from flask import Flask, render_template, Response
import cv2
from tkinter import *
from PIL import ImageTk, Image


def camra_window():
  print('Camera is turning on')
  cam = cv2.VideoCapture(0)
  while cam.isOpened():
    ret, frame1 = cam.read()
    ret, frame2 = cam.read()
    diff = cv2.absdiff(frame1, frame2)
    gray = cv2.cvtColor(diff, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
    dilated = cv2.dilate(thresh, None, iterations=3)
    contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    # cv2.drawContours(frame1, contours, -1, (0, 255, 0), 2)
    for c in contours:
        if cv2.contourArea(c) < 4000:
            #print(cv2.contourArea(c))
            continue
        x, y, w, h = cv2.boundingRect(c)
        cv2.rectangle(frame1, (x,y), (x+w,y+h), (0, 255, 0), 3)
        winsound.PlaySound('alert.wav', winsound.SND_ASYNC)
    if cv2.waitKey(10) == ord('q'):
        break
    cv2.imshow('Granny Cam', frame1)

#camra_window()
window = Tk()
window.title("ROBOT")
canvas = Canvas(window, width = 600, height = 1000)  
canvas.pack()
img =ImageTk.PhotoImage(Image.open("2.png"))  
canvas.create_image(20, 20, anchor=NW, image=img)
btn1 = Button(window, text = 'START', bd = 8,command = camra_window ,anchor='e',font=("comic sans",25,"bold",),bg='black',fg='white',relief='raised')
btn1.place(x=260,y=550)
window.mainloop()
